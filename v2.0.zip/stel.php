<?php
include 'connection.php';
$input=file_get_contents('php://input');
$data=json_decode($input);
$chat_id=$data->message->chat->id;
$text=$data->message->text; 
$email=$_COOKIE['email'];
$q1="SELECT * FROM Seller_info where numbe='$text'";
$sd=mysqli_query($conn,$q1);
$moto=mysqli_fetch_assoc($sd);
$ts=$moto['naam'];
$text=$ts." Thanks For joining The Revolution Lets Disrupt"." Click here: https://booksfiver.com/verio.php?id=$chat_id";
$url="https://api.telegram.org/bot1738147065:AAGkTAd1WG5bGzcY73UJUTBRuQDc57aUWx4/sendMessage?text=$text&chat_id=$chat_id";
file_get_contents($url);
?>