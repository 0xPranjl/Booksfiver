<?php
$dbname="id11160819_ocards";
$password="Y[w(a*s_6W@%i]FM";
$username="id11160819_pranjal";
$host="localhost";
$conn=mysqli_connect($host,$username,$password,$dbname);
?>