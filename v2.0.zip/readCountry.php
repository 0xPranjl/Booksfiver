<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
$m=$_POST["keyword"];
echo "afuewghdghrfhrr"
?>